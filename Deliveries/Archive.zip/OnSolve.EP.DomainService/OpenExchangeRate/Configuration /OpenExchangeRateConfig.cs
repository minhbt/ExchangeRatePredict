﻿using System;
namespace OnSolve.EP.SDK
{
    public class OpenExchangeRateConfig
    {
        public string Endpoint { get; set; }

        public string AppId { get; set; }
    }
}
