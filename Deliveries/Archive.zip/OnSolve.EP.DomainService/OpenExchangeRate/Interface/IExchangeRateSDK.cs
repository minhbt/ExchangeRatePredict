﻿using System;
using System.Threading;
using System.Threading.Tasks;
using OnSolve.EP.Models.API;

namespace OnSolve.EP.SDK
{
    public interface IExchangeRateSDK
    {
        
        string GetHistoricalURL();


    }
}
