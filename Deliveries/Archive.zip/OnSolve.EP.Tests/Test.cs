﻿using NUnit.Framework;
using System;
namespace OnSolve.EP.Tests
{
    [TestFixture()]
    public class Test
    {
        [Test()]
        public void TestCase()
        {
        }
    }
}
