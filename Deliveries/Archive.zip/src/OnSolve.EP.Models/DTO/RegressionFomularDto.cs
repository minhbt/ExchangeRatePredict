﻿using System;
namespace OnSolve.EP.Models.DTO
{
    public class RegressionFomularDto

    {

        public decimal Slope { get; private set; }

        public decimal Intercept { get; private set; }

    }
}
