﻿using System;
namespace OnSolve.EP.Models.API
{
    public class OpenExchangeRateBase
    {
        public string Endpoint { get; set; }

        public string AppId { get; set; }
    }
}
