﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Persona.EP.Models.API;
using Persona.EP.Models.Business;
using Persona.EP.Models.DTO;

namespace Persona.EP.Services
{
    public  interface IExchangeRateSourceService
    {
        Task<ExchangeRateBO> GetHistorical(
            ExchangeRateRequest exchangeRateRequest,
            CancellationToken cancellationToken = default(CancellationToken));
    }
}
