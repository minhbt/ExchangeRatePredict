﻿using System;
using System.Collections.Generic;

namespace Persona.EP.Services
{
    public interface ITimeSeriesService
    {
        IEnumerable<DateTime> MoveBackwardByMonth(DateTime targetDate, int count, bool includeTargetDate);
    }
}
