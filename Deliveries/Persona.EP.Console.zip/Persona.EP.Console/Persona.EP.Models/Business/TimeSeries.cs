namespace ExchangePredict.BuildBlocks.Models
{
    public enum TimeSeries
    {
        Backward,
        Forward
    }
}
