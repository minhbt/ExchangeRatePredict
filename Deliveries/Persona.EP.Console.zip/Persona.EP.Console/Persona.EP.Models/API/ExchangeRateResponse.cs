﻿
using System;
using System.Collections.Generic;

namespace Persona.EP.Models.API
{
    public class ExchangeRateResponse
    {

        public ExchangeRateResponse()
        {
        }

        public string Disclaimer { get; set; }

        public string License { get; set; }

        public DateTime Timestamp { get; set; }
       
        public string Base { get; set; }

        public Dictionary<string, decimal> Rates { get; set; }


    }
}
