﻿using System;
namespace Persona.EP.Models.DTO
{
    public class RegressionFomularDto

    {

        public decimal Slope { get; private set; }

        public decimal Intercept { get; private set; }

    }
}
