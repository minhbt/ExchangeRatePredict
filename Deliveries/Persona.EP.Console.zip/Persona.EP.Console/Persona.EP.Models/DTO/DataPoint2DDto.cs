﻿using System;
namespace Persona.EP.Models.DTO
{
    public class DataPoint2DDto
    {
        public decimal X { get; set; }
        public decimal Y { get; set; }
    }
}
