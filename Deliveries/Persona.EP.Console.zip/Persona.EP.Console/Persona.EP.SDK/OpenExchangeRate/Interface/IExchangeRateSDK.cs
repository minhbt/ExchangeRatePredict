﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Persona.EP.Models.API;

namespace Persona.EP.SDK
{
    public interface IExchangeRateSDK
    {
        
        string GetHistoricalURL();


    }
}
