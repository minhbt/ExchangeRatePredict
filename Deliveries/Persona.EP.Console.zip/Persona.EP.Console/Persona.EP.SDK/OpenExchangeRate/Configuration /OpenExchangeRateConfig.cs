﻿using System;
namespace Persona.EP.SDK
{
    public class OpenExchangeRateConfig
    {
        public string Endpoint { get; set; }

        public string AppId { get; set; }
    }
}
