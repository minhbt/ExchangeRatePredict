﻿using System;
namespace Persona.EP.API
{
    public class MyClass
    {
        public MyClass()
        {
        }
    }
}
