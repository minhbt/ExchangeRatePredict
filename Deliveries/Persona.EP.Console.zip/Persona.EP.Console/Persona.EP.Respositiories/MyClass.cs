﻿using System;
namespace Persona.EP.Respositiories
{
    public class MyClass
    {
        public MyClass()
        {
        }
    }
}
