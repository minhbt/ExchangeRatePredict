﻿using System.Collections.Generic;
using Persona.EP.Models.Business;

namespace Persona.EP.Repositories
{
    public interface IRegressionFomularRepository
    {
        RegressionFomularBO Create(List<DataPoint2dBO> samples);
    }
}
