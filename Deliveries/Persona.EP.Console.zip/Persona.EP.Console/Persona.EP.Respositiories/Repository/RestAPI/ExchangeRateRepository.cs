﻿using System;
using System.Threading.Tasks;
using Persona.EP.Models.API;
using Persona.EP.Repositories.Interfaces.RestAPI;



namespace Persona.EP.Repositories.RestAPI
{
    public class ExchangeRateRepository:IExchangeRateRepository
    {

        public Task<ExchangeRateResponse> GetExchangeRateAsync(ExchangeRateRequest ExchangeRateRqst)
        {
            throw new NotImplementedException();
        }
    }
}
