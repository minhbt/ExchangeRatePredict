﻿using System;
using Microsoft.Extensions.DependencyInjection;
using Persona.EP.Common.Helpers;
using Persona.EP.Services;

namespace Persona.EP.Console
{
    internal class MainClass
    {

        private const string FROM_ARG = "from";
        private const string TO_ARG = "to";
        public static void Main(string[] args)
        {
            var arguments = CommandLineParser.Parse(args);

            var from = string.Empty;
            var to = string.Empty;
            if (arguments.ContainsKey(FROM_ARG))
            {
                from = arguments[FROM_ARG];
            }

            if (arguments.ContainsKey(TO_ARG))
            {
                to = arguments[TO_ARG];
            }

            if (string.IsNullOrWhiteSpace(from) || string.IsNullOrWhiteSpace(to))
            {
                System.Console.WriteLine("You must provide \"from\" and \"to\" arguments");
                return;
            }

            var targetDate = new DateTime(2017, 1, 15);
            var services = new ServiceCollection();
            var numberOfSamples = 12;
            services.AddExchangePredict(opts =>
            {
                opts.Endpoint = "https://openexchangerates.org/api/";
                opts.AppId = "573c0c9d12e14355b304fcf52e240699";
            });
            var sp = services.BuildServiceProvider();
            var predictor = sp.GetService<IExchangeRatePredictService>();
            var result = predictor.PredictAsync(from, to, targetDate, numberOfSamples)
                .GetAwaiter()
                .GetResult();

            System.Console.WriteLine($"The predicted currency exchange from {from} to {to} for {targetDate.ToString("dd/MM/yyyy")} is {result,0:F3}");
            System.Console.ReadLine();
        }

        private string Replace(String word, char gone, char here)
        {

            string result = string.Empty;

            result = word.Replace('a', 'i');

            char[] CArray = word.ToCharArray();

            foreach (var item in CArray)
            {

            }

            return result;
        }

        private string GetLastFruitFromArray()
        {
            string lastFruit = string.Empty;
            var Objwords = new object[] { "apple", 1, 2, 3, 4, "Orange", 5, 6, 7 };
            for (var i = 0; i < Objwords.Length; i++)
            {
                if (Objwords[i] is string)
                {
                    lastFruit = (string)Objwords[i];
                }
                else
                {
                    int lastIntFromArray = (int)Objwords[i];
                }
            }


            return lastFruit;

        }
    }
}
