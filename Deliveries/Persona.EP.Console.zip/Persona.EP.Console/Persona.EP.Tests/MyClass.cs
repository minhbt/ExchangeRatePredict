﻿using System;
namespace Persona.EP.Tests
{
    public class MyClass
    {
        public MyClass()
        {
        }
    }
}
